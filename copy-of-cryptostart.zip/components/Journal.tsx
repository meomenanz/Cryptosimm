import React, { useEffect, useState } from 'react';
import { generateJournalEntry } from '../services/gemini';

const Journal: React.FC = () => {
  const [entry, setEntry] = useState<string>("Загружаю мысли ИИ...");
  
  useEffect(() => {
    generateJournalEntry().then(setEntry);
  }, []);

  const milestones = [
    { date: '12.05.2024', text: 'Купил первый ETH! Чувствую себя Виталиком.', done: true },
    { date: '15.05.2024', text: 'Рынок упал на 10%. Паника. Не продал.', done: true },
    { date: '20.05.2024', text: 'Зарегался на бирже. Учим матчасть.', done: true },
    { date: 'Сегодня', text: 'Изучаю DeFi и NFT.', done: false },
  ];

  return (
    <div className="p-4 pb-24">
       <div className="bg-gradient-to-r from-pink-500 to-rose-500 rounded-2xl p-6 mb-6 shadow-lg text-white relative overflow-hidden">
         <div className="absolute -right-4 -top-4 text-9xl opacity-10 rotate-12">📓</div>
         <h2 className="text-2xl font-bold mb-2">Дневник Криптана</h2>
         <p className="text-white/90 italic">"{entry}"</p>
         <div className="mt-2 text-xs font-bold text-white/70 text-right">— AI Мотиватор</div>
       </div>

       <div className="relative border-l-2 border-slate-700 ml-3 space-y-8 my-8">
         {milestones.map((m, i) => (
           <div key={i} className="mb-8 ml-6 relative">
             <span className={`absolute -left-[31px] flex items-center justify-center w-6 h-6 rounded-full ring-4 ring-slate-900 ${m.done ? 'bg-crypto-success' : 'bg-slate-600'}`}>
               {m.done && <span className="text-slate-900 text-xs font-bold">✓</span>}
             </span>
             <h3 className="flex items-center mb-1 text-lg font-semibold text-white">
               {m.date}
             </h3>
             <p className="text-base font-normal text-slate-400">{m.text}</p>
           </div>
         ))}
       </div>

       <div className="bg-slate-800/50 rounded-xl p-6 text-center border border-dashed border-slate-600">
         <span className="text-4xl mb-2 block">🎯</span>
         <h3 className="font-bold text-lg mb-1">Цель: 1 BTC</h3>
         <div className="w-full bg-slate-700 rounded-full h-2.5 mb-2 mt-2">
            <div className="bg-crypto-bitcoin h-2.5 rounded-full" style={{ width: '5%' }}></div>
         </div>
         <p className="text-xs text-slate-400">Прогресс: 0.05 / 1.0 BTC</p>
       </div>
    </div>
  );
};

export default Journal;
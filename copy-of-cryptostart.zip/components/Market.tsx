
import React, { useState } from 'react';
import { Coin } from '../types';
import TradeModal from './TradeModal';

interface MarketProps {
  coins: Coin[];
  balance: number;
  onTrade: (coinId: string, type: 'BUY' | 'SELL', amount: number) => void;
  fearGreed: number;
}

const Market: React.FC<MarketProps> = ({ coins, balance, onTrade, fearGreed }) => {
  const [selectedCoin, setSelectedCoin] = useState<Coin | null>(null);
  const [searchTerm, setSearchTerm] = useState('');

  const filteredCoins = coins.filter(c => 
    c.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    c.symbol.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getFearGreedLabel = (val: number) => {
    if (val < 20) return "😱 Экстремальный Страх";
    if (val < 40) return "😨 Страх";
    if (val < 60) return "😐 Нейтрально";
    if (val < 80) return "🤑 Жадность";
    return "🚀 Экстремальная Жадность";
  };

  const getFearGreedColor = (val: number) => {
    if (val < 20) return "bg-red-600";
    if (val < 40) return "bg-orange-500";
    if (val < 60) return "bg-yellow-500";
    if (val < 80) return "bg-green-500";
    return "bg-emerald-500";
  };

  return (
    <div className="p-4 pb-24">
      {/* Header & Search */}
      <div className="sticky top-0 bg-crypto-dark/95 backdrop-blur z-30 pb-4 pt-2 -mx-4 px-4 border-b border-slate-800">
        <div className="flex justify-between items-end mb-4">
          <h2 className="text-2xl font-bold flex items-center">
            <span className="mr-2 animate-bounce">🛒</span> Биржа
          </h2>
          <div className="text-right">
             <span className="text-xs text-slate-400 uppercase">Твой баланс</span>
             <div className="text-crypto-success font-mono font-bold text-xl">${balance.toLocaleString(undefined, { minimumFractionDigits: 2 })}</div>
          </div>
        </div>
        
        {/* Fear and Greed Widget */}
        <div className="mb-4 bg-slate-800/50 rounded-xl p-3 border border-slate-700 flex items-center justify-between">
           <div className="text-xs font-bold text-slate-400 uppercase">Индекс страха и жадности</div>
           <div className="flex items-center space-x-2">
             <span className="text-xs font-bold">{getFearGreedLabel(fearGreed)}</span>
             <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs text-black ${getFearGreedColor(fearGreed)}`}>
               {fearGreed.toFixed(0)}
             </div>
           </div>
        </div>

        <input 
          type="text" 
          placeholder="🔍 Найти гем..." 
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-white focus:border-crypto-accent outline-none transition-colors"
        />
      </div>

      <div className="space-y-3 mt-4">
        {filteredCoins.map((coin) => (
          <div key={coin.id} onClick={() => setSelectedCoin(coin)} className="group bg-crypto-card border border-slate-800 rounded-xl p-4 active:scale-[0.98] transition-all hover:border-crypto-accent/50 cursor-pointer relative overflow-hidden">
             {/* Background glow for memes */}
             {coin.symbol === 'DOGE' || coin.symbol === 'PEPE' ? (
                <div className="absolute top-0 right-0 w-20 h-20 bg-yellow-500/10 rounded-full blur-xl -mr-5 -mt-5"></div>
             ) : null}

            <div className="flex justify-between items-center">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 rounded-full flex items-center justify-center font-bold shadow-lg text-lg relative" style={{ backgroundColor: `${coin.color}20`, color: coin.color, border: `1px solid ${coin.color}40` }}>
                  {coin.symbol[0]}
                  {/* Small badge if owned */}
                  {coin.amount > 0 && (
                    <div className="absolute -bottom-1 -right-1 bg-crypto-success text-[8px] text-black font-bold px-1.5 py-0.5 rounded-full border border-slate-900">
                      OWN
                    </div>
                  )}
                </div>
                <div>
                  <h3 className="font-bold text-base flex items-center">
                    {coin.name}
                    {coin.change24h > 10 && <span className="ml-2 text-[10px] bg-crypto-accent px-1 rounded animate-pulse">HOT</span>}
                  </h3>
                  <div className="text-xs text-slate-400 font-mono">Vol: ${(Math.random() * 1000).toFixed(1)}M</div>
                </div>
              </div>
              
              <div className="text-right">
                <div className="text-lg font-mono font-bold">${coin.price.toLocaleString(undefined, { minimumFractionDigits: coin.price < 1 ? 4 : 2 })}</div>
                <div className={`text-xs font-bold px-2 py-1 rounded-md inline-block ${coin.change24h >= 0 ? 'bg-crypto-success/10 text-crypto-success' : 'bg-crypto-danger/10 text-crypto-danger'}`}>
                  {coin.change24h > 0 ? '▲' : '▼'} {Math.abs(coin.change24h).toFixed(2)}%
                </div>
              </div>
            </div>
            
            <div className="mt-3 flex justify-between items-center border-t border-slate-700/50 pt-2 opacity-60 group-hover:opacity-100 transition-opacity">
               <span className="text-[10px] text-slate-400">{coin.description || "Crypto Asset"}</span>
               <span className="text-[10px] font-bold text-crypto-accent">Нажми для торговли →</span>
            </div>
          </div>
        ))}
        
        {filteredCoins.length === 0 && (
           <div className="text-center py-10 text-slate-500">
             Ничего не найдено. Может, создать свой коин? 🤔
           </div>
        )}
      </div>

      {selectedCoin && (
        <TradeModal 
          coin={selectedCoin} 
          usdtBalance={balance}
          isOpen={!!selectedCoin}
          onClose={() => setSelectedCoin(null)}
          onTrade={onTrade}
        />
      )}
    </div>
  );
};

export default Market;


import React, { useMemo, useState } from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, AreaChart, Area, XAxis, YAxis } from 'recharts';
import { Coin, UserState, Achievement } from '../types';
import { roastPortfolio } from '../services/gemini';

interface DashboardProps {
  portfolio: Coin[];
  userState: UserState;
  onPanicSell?: () => void;
  onReset?: () => void;
  onClaimBonus?: () => void;
  achievementsList?: Achievement[];
}

const Dashboard: React.FC<DashboardProps> = ({ portfolio, userState, onPanicSell, onReset, onClaimBonus, achievementsList }) => {
  const [roast, setRoast] = useState<string | null>(null);
  const [loadingRoast, setLoadingRoast] = useState(false);
  const [showSettings, setShowSettings] = useState(false);

  const activeAssets = portfolio.filter(c => c.amount > 0);

  const totalPortfolioValue = useMemo(() => {
    return activeAssets.reduce((acc, coin) => acc + (coin.price * coin.amount), 0);
  }, [activeAssets, portfolio]);

  const totalNetWorth = totalPortfolioValue + userState.balanceUSDT;
  const totalPnL = totalNetWorth - userState.startBalance;
  const pnlPercent = (totalPnL / userState.startBalance) * 100;

  const data = [
    ...activeAssets.map(coin => ({
      name: coin.symbol,
      value: coin.price * coin.amount,
      color: coin.color
    })),
    { name: 'USDT', value: userState.balanceUSDT, color: '#10b981' }
  ];

  const handleRoast = async () => {
    if (loadingRoast) return;
    setLoadingRoast(true);
    const result = await roastPortfolio(activeAssets, userState.balanceUSDT, userState.startBalance);
    setRoast(result);
    setLoadingRoast(false);
  };

  const getLevelTitle = (level: number) => {
    if (level < 3) return "🐹 Хомяк";
    if (level < 5) return "👷‍♂️ Майнер";
    if (level < 10) return "📉 Трейдер";
    return "🐋 Кит";
  };

  const canClaimBonus = userState.lastDailyBonus !== new Date().toISOString().split('T')[0];

  const graphColor = totalPnL >= 0 ? '#10b981' : '#ef4444';
  const historyData = [
    { i: 1, val: userState.startBalance },
    { i: 2, val: userState.startBalance + (totalPnL * 0.2) },
    { i: 3, val: userState.startBalance + (totalPnL * 0.5) },
    { i: 4, val: userState.startBalance + (totalPnL * 0.1) },
    { i: 5, val: totalNetWorth },
  ];

  return (
    <div className="p-4 space-y-6 pb-24 animate-fade-in">
      
      {/* Settings Toggle */}
      <div className="flex justify-end">
        <button 
          onClick={() => setShowSettings(!showSettings)} 
          className="text-xs text-slate-400 flex items-center gap-1 bg-slate-800 px-3 py-1 rounded-full border border-slate-700 hover:border-crypto-accent"
        >
          ⚙️ {showSettings ? 'Скрыть профиль' : 'Профиль и Настройки'}
        </button>
      </div>

      {showSettings ? (
        <div className="bg-slate-800/80 rounded-2xl p-4 border border-slate-700 space-y-4 animate-fade-in">
          <h2 className="text-lg font-bold">👤 Профиль Игрока</h2>
          
          <div className="space-y-2">
            <h3 className="text-xs uppercase text-slate-400 font-bold">Достижения</h3>
            <div className="grid grid-cols-4 gap-2">
              {achievementsList?.map(ach => {
                const isUnlocked = userState.achievements.includes(ach.id);
                return (
                  <div key={ach.id} className={`aspect-square rounded-xl flex flex-col items-center justify-center p-1 border ${isUnlocked ? 'bg-crypto-accent/20 border-crypto-accent' : 'bg-slate-900 border-slate-800 opacity-50'}`}>
                    <span className="text-2xl">{ach.icon}</span>
                    <span className="text-[8px] text-center leading-tight mt-1">{ach.title}</span>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="pt-4 border-t border-slate-700">
            <button 
              onClick={onReset}
              className="w-full bg-red-500/10 border border-red-500/50 text-red-500 rounded-xl py-3 text-sm font-bold uppercase tracking-wider hover:bg-red-500 hover:text-white transition-all"
            >
              ⚠️ СБРОСИТЬ ВЕСЬ ПРОГРЕСС
            </button>
          </div>
        </div>
      ) : (
        <>
          {/* Level Progress */}
          <div className="flex items-center justify-between mb-2 px-1">
             <div className="flex items-center space-x-2">
               <span className="bg-slate-700 text-white text-xs px-2 py-0.5 rounded border border-slate-600">Lvl {userState.level}</span>
               <span className="text-sm font-bold text-crypto-accent">{getLevelTitle(userState.level)}</span>
             </div>
             <span className="text-xs text-slate-400">{userState.xp}/{(userState.level + 1) * 100} XP</span>
          </div>
          <div className="w-full bg-slate-800 rounded-full h-1.5 mb-4">
            <div 
              className="bg-gradient-to-r from-crypto-accent to-blue-500 h-1.5 rounded-full transition-all duration-500" 
              style={{ width: `${Math.min((userState.xp / ((userState.level + 1) * 100)) * 100, 100)}%` }}
            ></div>
          </div>

          {/* Daily Bonus */}
          {canClaimBonus && (
             <button 
               onClick={onClaimBonus}
               className="w-full mb-4 bg-gradient-to-r from-yellow-400 to-orange-500 text-black font-bold py-3 rounded-xl shadow-lg shadow-orange-500/20 animate-pulse flex items-center justify-center gap-2"
             >
               🎁 ЗАБРАТЬ БОНУС $100
             </button>
          )}

          {/* Main Net Worth Card */}
          <div className="bg-gradient-to-br from-slate-800 to-slate-900 border border-slate-700 rounded-3xl p-6 shadow-2xl relative overflow-hidden group">
            <div className={`absolute top-0 right-0 w-40 h-40 rounded-full blur-3xl -mr-10 -mt-10 transition-colors duration-1000 ${totalPnL >= 0 ? 'bg-crypto-success/20' : 'bg-crypto-danger/20'}`}></div>
            
            <h2 className="text-slate-400 text-xs font-semibold uppercase tracking-widest mb-1">Всего активов</h2>
            <div className="text-4xl font-mono font-bold text-white mb-2 tracking-tighter">
              ${totalNetWorth.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
            
            <div className="flex items-center space-x-3">
               <div className={`px-2 py-1 rounded-lg text-xs font-bold flex items-center ${totalPnL >= 0 ? 'bg-crypto-success/20 text-crypto-success' : 'bg-crypto-danger/20 text-crypto-danger'}`}>
                 {totalPnL >= 0 ? '🚀' : '📉'} {totalPnL > 0 ? '+' : ''}{pnlPercent.toFixed(2)}% (${totalPnL.toFixed(2)})
               </div>
               <div className="text-xs text-slate-500 font-mono">USDT: ${userState.balanceUSDT.toLocaleString()}</div>
            </div>
          </div>

          {/* Panic Sell Button */}
          {activeAssets.length > 0 && onPanicSell && (
            <button 
              onClick={() => {
                if(window.confirm("Ты уверен, что хочешь продать ВСЁ?! Это PANIC SELL!")) {
                   onPanicSell();
                }
              }}
              className="w-full bg-red-500/10 border border-red-500/50 text-red-500 rounded-xl py-3 text-sm font-bold uppercase tracking-wider hover:bg-red-500 hover:text-white transition-all animate-pulse"
            >
              😱 Panic Sell (Продать всё)
            </button>
          )}

          {/* AI Roast Section */}
          <div className="relative">
            {roast ? (
               <div className="bg-crypto-accent/10 border border-crypto-accent/30 rounded-2xl p-4 relative">
                 <button onClick={() => setRoast(null)} className="absolute top-2 right-2 text-crypto-accent opacity-50 hover:opacity-100">✕</button>
                 <div className="flex items-start space-x-3">
                   <span className="text-2xl">🔥</span>
                   <p className="text-sm italic text-crypto-accent/90">{roast}</p>
                 </div>
               </div>
            ) : (
              <button 
                onClick={handleRoast}
                disabled={loadingRoast}
                className="w-full py-3 bg-gradient-to-r from-orange-500/20 to-red-500/20 border border-orange-500/30 rounded-xl text-orange-400 text-sm font-bold flex items-center justify-center space-x-2 hover:bg-orange-500/30 transition-all"
              >
                {loadingRoast ? 'AI анализирует твой позор...' : '🌶️ Прожарить мой портфель'}
              </button>
            )}
          </div>

          {/* Chart Section */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-crypto-card rounded-2xl p-4 border border-slate-800 h-48">
              <h3 className="text-xs font-bold uppercase text-slate-400 mb-2">PnL График</h3>
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={historyData}>
                  <defs>
                    <linearGradient id="colorVal" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor={graphColor} stopOpacity={0.3}/>
                      <stop offset="95%" stopColor={graphColor} stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <XAxis dataKey="i" hide />
                  <YAxis hide domain={['auto', 'auto']} />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#1e293b', borderColor: '#334155', borderRadius: '8px', fontSize: '12px' }}
                    itemStyle={{ color: '#fff' }}
                    formatter={(val: number) => [`$${val.toFixed(2)}`, 'Value']}
                  />
                  <Area type="monotone" dataKey="val" stroke={graphColor} strokeWidth={3} fillOpacity={1} fill="url(#colorVal)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>

            <div className="bg-crypto-card rounded-2xl p-4 border border-slate-800 h-48 flex flex-col items-center justify-center relative">
              <h3 className="absolute top-4 left-4 text-xs font-bold uppercase text-slate-400">Аллокация</h3>
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={data}
                    cx="50%"
                    cy="50%"
                    innerRadius={40}
                    outerRadius={60}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {data.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} stroke="none" />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value: number) => `$${value.toFixed(2)}`} />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Holdings List */}
          <div className="bg-crypto-card rounded-2xl p-4 border border-slate-800">
            <h3 className="text-lg font-bold mb-4 flex items-center">📦 Твои мешки</h3>
            <div className="space-y-4">
              {activeAssets.length === 0 ? (
                <div className="text-center text-slate-500 py-4 text-sm">
                  Пусто... Купи что-нибудь на рынке!
                </div>
              ) : (
                activeAssets.map((coin) => (
                  <div key={coin.id} className="flex justify-between items-center border-b border-slate-800 last:border-0 pb-2 last:pb-0">
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 rounded-full flex items-center justify-center text-[10px] font-bold" style={{ backgroundColor: `${coin.color}30`, color: coin.color }}>
                        {coin.symbol}
                      </div>
                      <div>
                        <div className="font-bold text-sm">{coin.name}</div>
                        <div className="text-xs text-slate-400">{coin.amount.toFixed(4)} {coin.symbol}</div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-mono font-bold text-sm">${(coin.price * coin.amount).toLocaleString()}</div>
                      <div className={`text-[10px] ${coin.change24h >= 0 ? 'text-crypto-success' : 'text-crypto-danger'}`}>
                        {coin.change24h > 0 ? '+' : ''}{coin.change24h.toFixed(2)}%
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Recent Transactions */}
          {userState.transactions.length > 0 && (
            <div className="bg-crypto-card rounded-2xl p-4 border border-slate-800 opacity-80">
               <h3 className="text-xs font-bold uppercase text-slate-400 mb-3">История операций</h3>
               <div className="space-y-2">
                 {userState.transactions.slice(-3).reverse().map(tx => (
                   <div key={tx.id} className="flex justify-between text-xs">
                     <span className={tx.type === 'BUY' ? 'text-crypto-success' : 'text-crypto-danger'}>
                       {tx.type === 'BUY' ? 'BOUGHT' : 'SOLD'} {tx.symbol}
                     </span>
                     <span className="text-slate-400">
                       {tx.amount.toFixed(4)} @ ${tx.price.toLocaleString()}
                     </span>
                   </div>
                 ))}
               </div>
            </div>
          )}
        </>
      )}
    </div>
  );
};

export default Dashboard;

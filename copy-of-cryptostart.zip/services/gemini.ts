import { GoogleGenAI } from "@google/genai";
import { Coin } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const MODEL_NAME = 'gemini-2.5-flash';

export const getCryptoAdvice = async (history: { role: string, text: string }[], message: string): Promise<string> => {
  try {
    const chat = ai.chats.create({
      model: MODEL_NAME,
      config: {
        systemInstruction: `Ты — "Крипто-Бро", веселый и немного безумный трейдер. 
        Твоя задача: обучать новичка, используя сленг (FOMO, FUD, Rekt, To The Moon, Diamond Hands).
        Ты всегда поддерживаешь, даже если рынок падает ("Скидки!").
        Используй много эмодзи. Ответы должны быть короткими (для мобильного).`,
      },
      history: history.map(h => ({ role: h.role, parts: [{ text: h.text }] }))
    });

    const result = await chat.sendMessage({ message });
    return result.text || "Связь с космосом потеряна...";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Сеть перегружена, майнеры бастуют.";
  }
};

export const roastPortfolio = async (portfolio: Coin[], balance: number, startBalance: number): Promise<string> => {
  try {
    const holdings = portfolio.filter(c => c.amount > 0).map(c => `${c.name}: $${(c.amount * c.price).toFixed(2)}`).join(', ');
    const totalValue = portfolio.reduce((acc, c) => acc + (c.price * c.amount), 0) + balance;
    const profit = totalValue - startBalance;

    const prompt = `У пользователя в портфеле: ${holdings || "Ничего (пусто)"}. 
    Свободный кэш: $${balance.toFixed(2)}.
    Общий профит/убыток: ${profit > 0 ? '+' : ''}$${profit.toFixed(2)}.
    
    Сделай жесткую, но смешную "прожарку" (roast) этого портфеля. 
    Если убыток — шути про завод и доширак. 
    Если прибыль — шути про Ламбу и Дубай. 
    Максимум 3 предложения.`;

    const response = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: prompt,
    });
    return response.text || "Портфель настолько скучный, что мне нечего сказать.";
  } catch (error) {
    return "Не вижу твоих коинов, протри экран.";
  }
};

export const getBreakingNews = async (): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: "Придумай один ОЧЕНЬ короткий (макс 10 слов) смешной заголовок крипто-новости. Типа 'Биткоин упал, потому что меркурий в ретрограде' или 'Илон Маск купил планету за Doge'.",
    });
    return response.text || "Рынок двигается вправо.";
  } catch (error) {
    return "Биткоин все еще жив.";
  }
};

export const generateJournalEntry = async (): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: "Дай совет дня для крипто-хомяка. Одной фразой. Смешно.",
    });
    return response.text || "HODL до последнего!";
  } catch (error) {
    return "Купи на хаях, прокатись... ну ты знаешь.";
  }
};
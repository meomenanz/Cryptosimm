import React from 'react';
import { Tab } from '../types';

interface NavigationProps {
  activeTab: Tab;
  setActiveTab: (tab: Tab) => void;
}

const Navigation: React.FC<NavigationProps> = ({ activeTab, setActiveTab }) => {
  const navItems = [
    { id: Tab.DASHBOARD, label: 'Портфель', icon: '💼' },
    { id: Tab.MARKET, label: 'Рынок', icon: '📈' },
    { id: Tab.ADVISOR, label: 'AI Гуру', icon: '🤖' },
    { id: Tab.JOURNAL, label: 'Дневник', icon: '📓' },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-crypto-card/90 backdrop-blur-lg border-t border-slate-700 pb-safe pt-2 px-4 z-50">
      <div className="flex justify-between items-center max-w-md mx-auto h-16">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id)}
            className={`flex flex-col items-center justify-center w-full transition-all duration-300 ${
              activeTab === item.id ? 'text-crypto-accent scale-110' : 'text-slate-400'
            }`}
          >
            <span className="text-2xl mb-1">{item.icon}</span>
            <span className="text-[10px] font-bold uppercase tracking-wider">{item.label}</span>
          </button>
        ))}
      </div>
    </div>
  );
};

export default Navigation;
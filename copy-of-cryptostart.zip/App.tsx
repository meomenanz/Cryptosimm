
import React, { useState, useEffect, useCallback } from 'react';
import Navigation from './components/Navigation';
import Dashboard from './components/Dashboard';
import Market from './components/Market';
import ChatAdvisor from './components/ChatAdvisor';
import Journal from './components/Journal';
import { Tab, Coin, UserState, Transaction, Achievement } from './types';
import { getBreakingNews } from './services/gemini';

// Helper to generate fake history for charts
const generateHistory = (basePrice: number) => {
  let current = basePrice;
  return Array.from({ length: 30 }, () => {
    const change = (Math.random() - 0.5) * 0.02;
    current = current * (1 + change);
    return current;
  });
};

const INITIAL_MARKET_DATA: Coin[] = [
  { id: '1', symbol: 'BTC', name: 'Bitcoin', price: 64230.50, change24h: 2.4, amount: 0, color: '#f59e0b', description: "Digital Gold", priceHistory: [] },
  { id: '2', symbol: 'ETH', name: 'Ethereum', price: 3450.20, change24h: -1.2, amount: 0, color: '#6366f1', description: "Smart Contracts King", priceHistory: [] },
  { id: '3', symbol: 'SOL', name: 'Solana', price: 145.80, change24h: 5.7, amount: 0, color: '#10b981', description: "Fast & Furious", priceHistory: [] },
  { id: '4', symbol: 'TON', name: 'Toncoin', price: 6.85, change24h: 0.5, amount: 0, color: '#0088cc', description: "Telegram's Jewel", priceHistory: [] },
  { id: '5', symbol: 'DOGE', name: 'Dogecoin', price: 0.16, change24h: -3.4, amount: 0, color: '#eab308', description: "To the Moon!", priceHistory: [] },
  { id: '6', symbol: 'PEPE', name: 'Pepe', price: 0.0000078, change24h: 12.5, amount: 0, color: '#4ade80', description: "Rare Pepe", priceHistory: [] },
  { id: '7', symbol: 'SHIB', name: 'Shiba Inu', price: 0.000024, change24h: -0.8, amount: 0, color: '#ef4444', description: "Doge Killer", priceHistory: [] },
  { id: '8', symbol: 'XRP', name: 'Ripple', price: 0.62, change24h: 1.1, amount: 0, color: '#3b82f6', description: "The Banker", priceHistory: [] },
].map(c => ({ ...c, priceHistory: generateHistory(c.price) }));

const ACHIEVEMENTS_LIST: Achievement[] = [
  { id: 'first_trade', icon: '👶', title: 'Первая Кровь', description: 'Соверши первую сделку', condition: (u) => u.transactions.length > 0, unlocked: false },
  { id: 'level_5', icon: '👷‍♂️', title: 'Работяга', description: 'Достигни 5 уровня', condition: (u) => u.level >= 5, unlocked: false },
  { id: 'rich', icon: '💰', title: 'Мажор', description: 'Баланс выше $2000', condition: (u) => u.balanceUSDT >= 2000, unlocked: false },
  { id: 'broke', icon: '📉', title: 'Rekt', description: 'Баланс ниже $100', condition: (u) => u.balanceUSDT < 100, unlocked: false },
  { id: 'whale', icon: '🐋', title: 'Кит', description: 'Баланс выше $10,000', condition: (u) => u.balanceUSDT >= 10000, unlocked: false },
];

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<Tab>(Tab.DASHBOARD);
  
  // App State with Persistence Loading
  const [coins, setCoins] = useState<Coin[]>(INITIAL_MARKET_DATA);
  const [user, setUser] = useState<UserState>({
    balanceUSDT: 1000,
    startBalance: 1000,
    xp: 0,
    level: 1,
    transactions: [],
    lastDailyBonus: null,
    achievements: []
  });
  
  const [news, setNews] = useState<string>("Загрузка новостей рынка...");
  const [notification, setNotification] = useState<string | null>(null);
  const [fearGreedIndex, setFearGreedIndex] = useState(50);
  const [isLoaded, setIsLoaded] = useState(false);

  // Load from LocalStorage on Mount
  useEffect(() => {
    const savedUser = localStorage.getItem('crypto_user');
    const savedCoins = localStorage.getItem('crypto_coins');

    if (savedUser) {
      setUser(JSON.parse(savedUser));
    }
    if (savedCoins) {
      const parsedCoins = JSON.parse(savedCoins);
      // Merge saved amounts with current market structure (to keep prices fresh but amounts saved)
      setCoins(prev => prev.map(c => {
        const saved = parsedCoins.find((sc: any) => sc.id === c.id);
        return saved ? { ...c, amount: saved.amount } : c;
      }));
    }
    setIsLoaded(true);
  }, []);

  // Save to LocalStorage on Change
  useEffect(() => {
    if (!isLoaded) return;
    localStorage.setItem('crypto_user', JSON.stringify(user));
    // Only save ID and Amount to avoid saving stale prices
    const coinsToSave = coins.map(c => ({ id: c.id, amount: c.amount }));
    localStorage.setItem('crypto_coins', JSON.stringify(coinsToSave));
  }, [user, coins, isLoaded]);

  // Check Achievements
  useEffect(() => {
    ACHIEVEMENTS_LIST.forEach(ach => {
      if (!user.achievements.includes(ach.id) && ach.condition(user)) {
        setUser(prev => ({ ...prev, achievements: [...prev.achievements, ach.id] }));
        showNotification(`🏆 Достижение: ${ach.title}!`);
        if (navigator.vibrate) navigator.vibrate([100, 50, 100, 50, 100]);
      }
    });
  }, [user.balanceUSDT, user.transactions, user.level]);

  // Market Simulator (Ticker)
  useEffect(() => {
    const interval = setInterval(() => {
      setCoins(prevCoins => prevCoins.map(coin => {
        const volatility = coin.symbol === 'PEPE' || coin.symbol === 'SHIB' ? 0.04 : 0.01; 
        const change = (Math.random() - 0.5) * volatility;
        const newPrice = coin.price * (1 + change);
        const newHistory = [...coin.priceHistory, newPrice].slice(-30);

        return {
          ...coin,
          price: Math.max(0.00000001, newPrice),
          change24h: coin.change24h + (change * 100),
          priceHistory: newHistory
        };
      }));
      setFearGreedIndex(prev => Math.max(0, Math.min(100, prev + (Math.random() - 0.5) * 5)));
    }, 2000); 

    return () => clearInterval(interval);
  }, []);

  // News Ticker
  useEffect(() => {
    getBreakingNews().then(setNews);
    const newsInterval = setInterval(() => {
       getBreakingNews().then(setNews);
    }, 30000);
    return () => clearInterval(newsInterval);
  }, []);

  const handleTrade = useCallback((coinId: string, type: 'BUY' | 'SELL', amount: number) => {
    const coinIndex = coins.findIndex(c => c.id === coinId);
    if (coinIndex === -1) return;

    const coin = coins[coinIndex];
    const cost = amount * coin.price;
    const gasFee = type === 'BUY' ? 1.5 : 1.5; // Fixed fake gas fee

    if (navigator.vibrate) navigator.vibrate(50);

    if (type === 'BUY') {
      const totalCost = cost + gasFee;
      if (user.balanceUSDT < totalCost) {
        showNotification("❌ Недостаточно USDT (учитывай газ)!");
        return;
      }
      setUser(prev => ({
        ...prev,
        balanceUSDT: prev.balanceUSDT - totalCost,
        xp: prev.xp + 15,
        transactions: [...prev.transactions, { id: Date.now().toString(), type, symbol: coin.symbol, amount, price: coin.price, date: new Date() }]
      }));
      setCoins(prev => {
        const newCoins = [...prev];
        newCoins[coinIndex].amount += amount;
        return newCoins;
      });
      showNotification(`✅ Куплено ${amount.toFixed(4)} ${coin.symbol}!`);
    } else {
      if (coin.amount < amount) {
        showNotification("❌ Недостаточно монет!");
        return;
      }
      const totalReceive = cost - gasFee;
      setUser(prev => ({
        ...prev,
        balanceUSDT: prev.balanceUSDT + totalReceive,
        xp: prev.xp + 15,
        transactions: [...prev.transactions, { id: Date.now().toString(), type, symbol: coin.symbol, amount, price: coin.price, date: new Date() }]
      }));
      setCoins(prev => {
        const newCoins = [...prev];
        newCoins[coinIndex].amount -= amount;
        return newCoins;
      });
      showNotification(`💰 Продано ${amount.toFixed(4)} ${coin.symbol}!`);
    }

    if (user.xp > (user.level + 1) * 100) {
       setUser(prev => ({ ...prev, level: prev.level + 1 }));
       showNotification("🎉 LEVEL UP! Ты теперь круче!");
    }
  }, [coins, user.balanceUSDT, user.xp, user.level]);

  const handlePanicSell = useCallback(() => {
    let totalGot = 0;
    let newBalance = user.balanceUSDT;
    const newTransactions = [...user.transactions];

    const newCoins = coins.map(c => {
      if (c.amount > 0) {
        const value = c.amount * c.price;
        totalGot += value;
        newBalance += value; // Panic sell ignores gas fees out of pity
        newTransactions.push({
          id: Date.now().toString() + c.id,
          type: 'SELL',
          symbol: c.symbol,
          amount: c.amount,
          price: c.price,
          date: new Date()
        });
        return { ...c, amount: 0 };
      }
      return c;
    });

    if (totalGot > 0) {
      setCoins(newCoins);
      setUser(prev => ({ ...prev, balanceUSDT: newBalance, transactions: newTransactions }));
      showNotification(`😱 PANIC SELL! Слито на $${totalGot.toFixed(2)}`);
    } else {
      showNotification("🤷‍♂️ Нечего продавать!");
    }
  }, [coins, user.balanceUSDT, user.transactions]);

  const handleReset = () => {
    if (confirm("⚠️ ТЫ УВЕРЕН? ВЕСЬ ПРОГРЕСС БУДЕТ УДАЛЕН НАВСЕГДА!")) {
      localStorage.removeItem('crypto_user');
      localStorage.removeItem('crypto_coins');
      window.location.reload();
    }
  };

  const handleDailyBonus = () => {
    const today = new Date().toISOString().split('T')[0];
    if (user.lastDailyBonus !== today) {
      setUser(prev => ({
        ...prev,
        balanceUSDT: prev.balanceUSDT + 100,
        lastDailyBonus: today
      }));
      showNotification("🎁 Ежедневный бонус +$100 USDT получен!");
      if (navigator.vibrate) navigator.vibrate([50, 50, 50]);
    }
  };

  const showNotification = (msg: string) => {
    setNotification(msg);
    setTimeout(() => setNotification(null), 3000);
  };

  const renderContent = () => {
    switch (activeTab) {
      case Tab.DASHBOARD:
        return <Dashboard 
          portfolio={coins} 
          userState={user} 
          onPanicSell={handlePanicSell} 
          onReset={handleReset}
          onClaimBonus={handleDailyBonus}
          achievementsList={ACHIEVEMENTS_LIST}
        />;
      case Tab.MARKET:
        return <Market coins={coins} balance={user.balanceUSDT} onTrade={handleTrade} fearGreed={fearGreedIndex} />;
      case Tab.ADVISOR:
        return <ChatAdvisor />;
      case Tab.JOURNAL:
        return <Journal />;
      default:
        return <Dashboard portfolio={coins} userState={user} onPanicSell={handlePanicSell} />;
    }
  };

  if (!isLoaded) return <div className="h-screen w-full flex items-center justify-center bg-crypto-dark text-white">Загрузка кошелька...</div>;

  return (
    <div className="min-h-screen bg-crypto-dark text-white font-sans selection:bg-crypto-accent selection:text-white pb-safe">
      {notification && (
        <div className="fixed top-24 left-1/2 transform -translate-x-1/2 bg-slate-800 border border-crypto-accent/50 text-white px-6 py-3 rounded-full shadow-2xl z-[70] animate-bounce flex items-center gap-2 whitespace-nowrap">
          {notification}
        </div>
      )}

      {activeTab !== Tab.ADVISOR && (
        <header className="px-4 pt-6 pb-2 sticky top-0 z-40 bg-crypto-dark/80 backdrop-blur-md">
          <div className="flex justify-between items-center mb-2">
            <div>
              <h1 className="text-xl font-bold font-mono tracking-tighter bg-clip-text text-transparent bg-gradient-to-r from-crypto-accent to-blue-500">
                CRYPTO<span className="text-white">SIM</span>
              </h1>
              <p className="text-[10px] text-slate-400 font-mono">Баланс: ${user.balanceUSDT.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
            </div>
            <div className="flex items-center space-x-2">
               <div className="text-right">
                  <div className="text-[10px] text-slate-500 uppercase">Уровень {user.level}</div>
                  <div className="h-1 w-16 bg-slate-800 rounded-full mt-1">
                     <div className="h-full bg-crypto-accent rounded-full" style={{ width: `${Math.min((user.xp / ((user.level + 1) * 100)) * 100, 100)}%` }}></div>
                  </div>
               </div>
               <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-purple-500 to-pink-500 p-[2px]">
                <div className="w-full h-full rounded-full bg-slate-900 flex items-center justify-center overflow-hidden">
                  <span className="text-lg">😎</span>
                </div>
              </div>
            </div>
          </div>
          
          <div className="w-full bg-slate-800/50 rounded-lg overflow-hidden py-1 border border-slate-700/50">
             <div className="whitespace-nowrap animate-[marquee_15s_linear_infinite] text-xs font-mono text-crypto-accent">
               🚨 {news} &nbsp;&nbsp;&nbsp; • &nbsp;&nbsp;&nbsp; 🚨 {news}
             </div>
          </div>
        </header>
      )}

      <main className="max-w-md mx-auto min-h-screen relative pt-2">
        {renderContent()}
      </main>

      <Navigation activeTab={activeTab} setActiveTab={setActiveTab} />
      
      <style>{`
        @keyframes marquee {
          0% { transform: translateX(100%); }
          100% { transform: translateX(-100%); }
        }
      `}</style>
    </div>
  );
};

export default App;


export interface Coin {
  id: string;
  symbol: string;
  name: string;
  price: number;
  change24h: number;
  amount: number; // Amount owned
  color: string;
  description?: string;
  priceHistory: number[]; // Array of past prices for the chart
}

export interface Transaction {
  id: string;
  type: 'BUY' | 'SELL';
  symbol: string;
  amount: number;
  price: number;
  date: Date;
}

export interface Achievement {
  id: string;
  icon: string;
  title: string;
  description: string;
  unlocked: boolean;
  condition: (user: UserState) => boolean;
}

export interface UserState {
  balanceUSDT: number;
  startBalance: number;
  xp: number; // For leveling up
  level: number;
  transactions: Transaction[];
  lastDailyBonus: string | null; // ISO Date string
  achievements: string[]; // IDs of unlocked achievements
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: Date;
}

export enum Tab {
  DASHBOARD = 'DASHBOARD',
  MARKET = 'MARKET',
  ADVISOR = 'ADVISOR',
  JOURNAL = 'JOURNAL'
}


import React, { useState, useMemo } from 'react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import { Coin } from '../types';

interface TradeModalProps {
  coin: Coin;
  usdtBalance: number;
  isOpen: boolean;
  onClose: () => void;
  onTrade: (coinId: string, type: 'BUY' | 'SELL', amount: number) => void;
}

const TradeModal: React.FC<TradeModalProps> = ({ coin, usdtBalance, isOpen, onClose, onTrade }) => {
  const [amount, setAmount] = useState<string>('');
  const [mode, setMode] = useState<'BUY' | 'SELL'>('BUY');
  
  // Fake Gas Fee
  const GAS_FEE = 1.50;

  // Prepare Chart Data
  const chartData = useMemo(() => {
    return coin.priceHistory.map((p, i) => ({ index: i, price: p }));
  }, [coin.priceHistory]);

  const isGoingUp = coin.priceHistory.length > 1 && 
    coin.priceHistory[coin.priceHistory.length - 1] > coin.priceHistory[coin.priceHistory.length - 2];
  
  const chartColor = isGoingUp ? '#10b981' : '#ef4444';

  if (!isOpen) return null;

  const numAmount = parseFloat(amount) || 0;
  const rawCost = numAmount * coin.price;
  const totalCost = mode === 'BUY' ? rawCost + GAS_FEE : rawCost - GAS_FEE;
  
  const isValid = numAmount > 0 && (mode === 'BUY' ? totalCost <= usdtBalance : numAmount <= coin.amount);

  const setPercentage = (pct: number) => {
    if (mode === 'BUY') {
      const maxUsdt = Math.max(0, usdtBalance - GAS_FEE);
      const val = (maxUsdt * pct) / coin.price;
      setAmount(val.toFixed(6));
    } else {
      setAmount((coin.amount * pct).toFixed(6));
    }
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-end sm:items-center justify-center bg-black/80 backdrop-blur-md animate-fade-in">
      <div className="w-full max-w-md bg-slate-900 border-t sm:border border-slate-700 rounded-t-3xl sm:rounded-2xl p-6 shadow-2xl transform transition-transform duration-300 max-h-[90vh] overflow-y-auto no-scrollbar">
        
        {/* Header */}
        <div className="flex justify-between items-center mb-4">
          <div className="flex items-center gap-3">
             <div className="w-10 h-10 rounded-full flex items-center justify-center font-bold text-lg" style={{ backgroundColor: coin.color }}>
                {coin.symbol[0]}
             </div>
             <div>
                <h2 className="text-xl font-bold leading-none">{coin.name}</h2>
                <span className={`text-xs font-bold ${isGoingUp ? 'text-crypto-success' : 'text-crypto-danger'}`}>
                  ${coin.price.toLocaleString()} ({isGoingUp ? '▲' : '▼'})
                </span>
             </div>
          </div>
          <button onClick={onClose} className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center text-slate-400 hover:bg-slate-700">✕</button>
        </div>

        {/* Live Chart */}
        <div className="bg-slate-800/30 rounded-xl p-0 border border-slate-700/50 mb-4 h-32 relative overflow-hidden">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={chartData}>
              <defs>
                <linearGradient id="colorPrice" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor={chartColor} stopOpacity={0.3}/>
                  <stop offset="95%" stopColor={chartColor} stopOpacity={0}/>
                </linearGradient>
              </defs>
              <Area type="monotone" dataKey="price" stroke={chartColor} strokeWidth={2} fillOpacity={1} fill="url(#colorPrice)" />
              <YAxis domain={['auto', 'auto']} hide />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Mode Switcher */}
        <div className="flex bg-slate-800 rounded-xl p-1 mb-6 relative overflow-hidden">
          <div 
             className={`absolute top-1 bottom-1 w-[48%] bg-slate-700 rounded-lg transition-all duration-300 ${mode === 'BUY' ? 'left-1 bg-crypto-success' : 'left-[51%] bg-crypto-danger'}`}
          ></div>
          <button 
            onClick={() => setMode('BUY')}
            className={`flex-1 py-3 rounded-lg font-bold text-sm relative z-10 transition-colors ${mode === 'BUY' ? 'text-white' : 'text-slate-400'}`}
          >
            КУПИТЬ
          </button>
          <button 
            onClick={() => setMode('SELL')}
            className={`flex-1 py-3 rounded-lg font-bold text-sm relative z-10 transition-colors ${mode === 'SELL' ? 'text-white' : 'text-slate-400'}`}
          >
            ПРОДАТЬ
          </button>
        </div>

        {/* Balance Info */}
        <div className="flex justify-between text-xs text-slate-400 mb-2 px-1">
           <span>Баланс: <span className="text-white font-mono">${usdtBalance.toFixed(2)}</span></span>
           <span>В наличии: <span className="text-white font-mono">{coin.amount.toFixed(6)} {coin.symbol}</span></span>
        </div>

        {/* Input Area */}
        <div className="relative mb-4">
          <input 
            type="number" 
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            placeholder="0.00"
            className="w-full bg-slate-800 border border-slate-700 focus:border-crypto-accent rounded-xl py-4 pl-4 pr-16 text-3xl font-mono text-white outline-none placeholder:text-slate-600"
          />
          <span className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-500 font-bold">{coin.symbol}</span>
        </div>

        {/* Quick Percentage Buttons */}
        <div className="grid grid-cols-4 gap-2 mb-6">
           {[0.25, 0.50, 0.75, 1].map((pct) => (
             <button
               key={pct}
               onClick={() => setPercentage(pct)}
               className="bg-slate-800 hover:bg-slate-700 py-2 rounded-lg text-xs font-bold text-slate-300 transition-colors border border-slate-700"
             >
               {pct === 1 ? 'MAX' : `${pct * 100}%`}
             </button>
           ))}
        </div>

        {/* Summary Info */}
        <div className="bg-slate-800/50 rounded-xl p-4 mb-6 space-y-2 border border-slate-700/50">
           <div className="flex justify-between text-xs">
              <span className="text-slate-400">Стоимость</span>
              <span className="font-mono text-white">${rawCost.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
           </div>
           <div className="flex justify-between text-xs">
              <span className="text-slate-400">Сетевой сбор (Gas)</span>
              <span className="font-mono text-yellow-500">~${GAS_FEE.toFixed(2)}</span>
           </div>
           <div className="border-t border-slate-700/50 pt-2 flex justify-between text-sm font-bold">
              <span>Итого {mode === 'BUY' ? 'с вас' : 'вы получите'}</span>
              <span className={mode === 'BUY' ? 'text-crypto-danger' : 'text-crypto-success'}>
                ${totalCost > 0 ? totalCost.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : '0.00'}
              </span>
           </div>
        </div>

        {/* Action Button */}
        <button 
          onClick={() => {
            onTrade(coin.id, mode, numAmount);
            onClose();
          }}
          disabled={!isValid}
          className={`w-full py-4 rounded-xl font-bold text-lg shadow-lg transform active:scale-[0.98] transition-all flex items-center justify-center gap-2 ${
            isValid 
             ? (mode === 'BUY' ? 'bg-crypto-success hover:bg-green-600 text-white shadow-green-900/20' : 'bg-crypto-danger hover:bg-red-600 text-white shadow-red-900/20')
             : 'bg-slate-800 text-slate-500 cursor-not-allowed'
          }`}
        >
          {mode === 'BUY' ? `КУПИТЬ ${coin.symbol}` : `ПРОДАТЬ ${coin.symbol}`}
        </button>
      </div>
    </div>
  );
};

export default TradeModal;
